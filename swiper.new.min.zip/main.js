ScrollTrigger.matchMedia({
  "(min-width: 769px)": function() {

  }, 
  "(max-width: 768px)": function() {

  }, 
  "all": function() {

  }  
});